import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'; // Import the CSS
import './AddBilling.css'; // Import custom CSS for styling

const AddBilling = () => {
    const [billing, setBilling] = useState({ customerId: '', products: [], totalAmount: 0 });
    const [customers, setCustomers] = useState([]);
    const [products, setProducts] = useState([]);

    useEffect(() => {
        const fetchCustomers = async () => {
            const response = await axios.get('http://localhost:4000/api/customers');
            setCustomers(response.data);
        };

        const fetchProducts = async () => {
            const response = await axios.get('http://localhost:4000/api/products');
            setProducts(response.data);
        };

        fetchCustomers();
        fetchProducts();
    }, []);

    const handleCustomerChange = (e) => {
        setBilling({ ...billing, customerId: e.target.value });
    };

    const handleProductChange = (productId, quantity) => {
        const product = products.find(p => p._id === productId);
        if (product && quantity > 0) {
            const totalAmount = product.price * quantity;
            setBilling(prev => ({
                ...prev,
                products: [...prev.products, { productId, quantity }],
                totalAmount: prev.totalAmount + totalAmount
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:4000/api/billing/add', billing);
            toast.success('Billing added successfully!'); // Show success toast
            setBilling({ customerId: '', products: [], totalAmount: 0 });
        } catch (error) {
            toast.error('Failed to add billing!'); // Show error toast
        }
    };

    return (
        <div className="add-billing-container">
            <h2>Add Billing</h2>
            <form onSubmit={handleSubmit} className="add-billing-form">
                <select onChange={handleCustomerChange} required>
                    <option value="">Select Customer</option>
                    {customers.map(customer => (
                        <option key={customer._id} value={customer._id}>{customer.name}</option>
                    ))}
                </select>
                {products.map(product => (
                    <div key={product._id} className="product-item">
                        <span>{product.name} - ${product.price}</span>
                        <input
                            type="number"
                            min="1"
                            placeholder="Quantity"
                            onChange={(e) => handleProductChange(product._id, e.target.value)}
                        />
                    </div>
                ))}
                <h3>Total Amount: ${billing.totalAmount.toFixed(2)}</h3>
                <button type="submit">Add Billing</button>
            </form>
            <ToastContainer /> {/* Add ToastContainer to your component */}
        </div>
    );
};

export default AddBilling;
