import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ViewBilling.css';
import Modal from 'react-modal';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ViewBilling = () => {
    const [billings, setBillings] = useState([]);
    const [isEditing, setIsEditing] = useState(false);
    const [currentBilling, setCurrentBilling] = useState(null);

    useEffect(() => {
        const fetchBillings = async () => {
            const response = await axios.get('http://localhost:4000/api/billing');
            setBillings(response.data);
        };
        fetchBillings();
    }, []);

    const handlePrint = (billing) => {
        // Print logic remains the same
    };

    const handleDelete = async (id) => {
        try {
            await axios.delete(`http://localhost:4000/api/billing/${id}`);
            setBillings(billings.filter(billing => billing._id !== id));
            toast.success('Billing record deleted successfully');
        } catch (error) {
            console.error("Failed to delete billing:", error);
            toast.error('Failed to delete billing record');
        }
    };

    const handleEdit = (billing) => {
        setCurrentBilling(billing);
        setIsEditing(true);
    };

    const saveEdit = async (updatedBilling) => {
        try {
            const response = await axios.put(`http://localhost:4000/api/billing/${updatedBilling._id}`, updatedBilling);
            setBillings(billings.map(billing => (billing._id === response.data._id ? response.data : billing)));
            setIsEditing(false);
            setCurrentBilling(null);
            toast.success('Billing record updated successfully');
        } catch (error) {
            console.error("Failed to update billing:", error);
            toast.error('Failed to update billing record');
        }
    };

    return (
        <div className="view-billing-container">
            <h2>Billing Records</h2>
            <table className="billing-table">
                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>Total Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {billings.map(billing => (
                        <tr key={billing._id}>
                            <td>{billing.customerId.name}</td>
                            <td>${billing.totalAmount.toFixed(2)}</td>
                            <td>
                                <button onClick={() => handlePrint(billing)}>Print Bill</button>
                                <button onClick={() => handleEdit(billing)}>Edit</button>
                                <button onClick={() => handleDelete(billing._id)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <Modal
                isOpen={isEditing}
                onRequestClose={() => setIsEditing(false)}
                contentLabel="Edit Billing"
            >
                <EditBillingForm 
                    billing={currentBilling} 
                    onSave={saveEdit} 
                    onCancel={() => setIsEditing(false)} 
                />
            </Modal>

            <ToastContainer />
        </div>
    );
};

// EditBillingForm component
const EditBillingForm = ({ billing, onSave, onCancel }) => {
    const [updatedBilling, setUpdatedBilling] = useState(billing);

    useEffect(() => {
        setUpdatedBilling(billing);
    }, [billing]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUpdatedBilling(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave(updatedBilling);
    };

    return (
        <div className="edit-billing-form">
            <h3>Edit Billing</h3>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Customer Name:</label>
                    <input 
                        type="text" 
                        name="customerId" 
                        value={updatedBilling.customerId.name} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <div>
                    <label>Total Amount:</label>
                    <input 
                        type="number" 
                        name="totalAmount" 
                        value={updatedBilling.totalAmount} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                {/* Handle product fields as necessary */}
                <button type="submit">Save</button>
                <button type="button" onClick={onCancel}>Cancel</button>
            </form>
        </div>
    );
};

export default ViewBilling;
