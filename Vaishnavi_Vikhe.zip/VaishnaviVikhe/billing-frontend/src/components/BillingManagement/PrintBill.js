// PrintBill.js
import React from 'react';

const PrintBill = ({ billing }) => {
    return (
        <div>
            <h2>Bill Details</h2>
            <p><strong>Customer:</strong> {billing.customerId.name}</p>
            <p><strong>Total Amount:</strong> ${billing.totalAmount.toFixed(2)}</p>
            <h3>Products:</h3>
            <ul>
                {billing.products.map((product, index) => (
                    <li key={index}>
                        {product.productId.name} - Quantity: {product.quantity}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default PrintBill;
