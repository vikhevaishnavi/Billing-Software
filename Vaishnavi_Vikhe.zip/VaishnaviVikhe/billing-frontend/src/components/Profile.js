import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Profile = () => {
    const [user, setUser] = useState({ name: '', email: '' });

    useEffect(() => {
        const fetchUserProfile = async () => {
            try {
                const response = await axios.get('http://localhost:4000/api/users/profile', {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}` // Ensure the token is sent
                    }
                });
                setUser(response.data);
            } catch (error) {
                toast.error('Failed to fetch user profile');
                console.error('Error fetching profile:', error);
            }
        };

        fetchUserProfile();
    }, []);

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.put('http://localhost:4000/api/users/update', user, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}` // Ensure the token is sent
                }
            });
            setUser(response.data); // Update state with the latest user info
            toast.success('Profile updated successfully!');
        } catch (error) {
            toast.error('Failed to update profile!');
            console.error('Error updating profile:', error);
        }
    };

    return (
        <div>
            <h2>Profile</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="name" value={user.name} onChange={handleChange} placeholder="Name" required />
                <input type="email" name="email" value={user.email} onChange={handleChange} placeholder="Email" required />
                <button type="submit">Update Profile</button>
            </form>
            <ToastContainer />
        </div>
    );
};

export default Profile;
