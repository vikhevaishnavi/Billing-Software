import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Header.css'; // Import your CSS file

const Header = () => {
    const [notifications, setNotifications] = useState([]);
    const [showNotifications, setShowNotifications] = useState(false);

    const toggleNotifications = () => {
        setShowNotifications(!showNotifications);
    };

    const addNotification = (message) => {
        setNotifications(prev => [...prev, message]);
    };

    return (
        <header className="header">
            <div className="logo">Billing Software</div>
            <div className="header-right">
                <input type="text" placeholder="Search..." className="search-bar" />
                <div className="notification-bell" onClick={toggleNotifications}>
                    🔔
                    {notifications.length > 0 && <span className="notification-count">{notifications.length}</span>}
                </div>
                {showNotifications && (
                    <div className="notification-dropdown">
                        {notifications.length > 0 ? (
                            notifications.map((notif, index) => (
                                <div key={index} className="notification-item">{notif}</div>
                            ))
                        ) : (
                            <div className="notification-item">No new notifications</div>
                        )}
                    </div>
                )}
                <Link to="/profile" className="profile-link">Profile</Link>
            </div>
        </header>
    );
};

export default Header;
