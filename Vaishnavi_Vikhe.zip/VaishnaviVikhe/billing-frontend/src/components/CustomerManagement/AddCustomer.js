import React, { useState } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'; // Import the CSS
import './AddCustomer.css'; // Import custom CSS for styling

const AddCustomer = () => {
    const [customer, setCustomer] = useState({ name: '', gender: '', contact: '', email: '' });

    const handleChange = (e) => {
        setCustomer({ ...customer, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:4000/api/customers/add', customer);
            toast.success('Customer added successfully!'); // Show success toast
            setCustomer({ name: '', gender: '', contact: '', email: '' });
        } catch (error) {
            toast.error('Failed to add customer!'); // Show error toast
        }
    };

    return (
        <div className="add-customer-container">
            <h2>Add Customer</h2>
            <form onSubmit={handleSubmit} className="customer-form">
                <input type="text" name="name" value={customer.name} onChange={handleChange} placeholder="Name" required />
                <select name="gender" value={customer.gender} onChange={handleChange} required>
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
                <input type="text" name="contact" value={customer.contact} onChange={handleChange} placeholder="Contact" required />
                <input type="email" name="email" value={customer.email} onChange={handleChange} placeholder="Email" required />
                <button type="submit">Save</button>
            </form>
            <ToastContainer /> {/* Add ToastContainer to your component */}
        </div>
    );
};

export default AddCustomer;
