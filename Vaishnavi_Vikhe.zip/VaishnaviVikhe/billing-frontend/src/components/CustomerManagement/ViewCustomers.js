import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ViewCustomers.css'; // Import custom CSS for styling

const ViewCustomers = () => {
    const [customers, setCustomers] = useState([]);

    useEffect(() => {
        const fetchCustomers = async () => {
            try {
                const response = await axios.get('http://localhost:4000/api/customers');
                setCustomers(response.data);
            } catch (error) {
                console.error('Error fetching customers:', error);
            }
        };
        fetchCustomers();
    }, []);

    return (
        <div className="view-customers-container">
            <h2>Customers</h2>
            {customers.length === 0 ? (
                <p>No customers found.</p>
            ) : (
                <table className="customers-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Gender</th>
                        </tr>
                    </thead>
                    <tbody>
                        {customers.map(customer => (
                            <tr key={customer._id}>
                                <td>{customer.name}</td>
                                <td>{customer.email}</td>
                                <td>{customer.contact}</td>
                                <td>{customer.gender}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};

export default ViewCustomers;
