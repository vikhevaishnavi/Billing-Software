import React, { useState } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'; // Import the CSS
import './AddProduct.css'; // Import custom CSS for styling

const AddProduct = () => {
    const [product, setProduct] = useState({
        name: '',
        price: '',
        quantity: '',
        brand: '',
        supplier: '',
        oldStock: '',
        category: ''
    });

    const handleChange = (e) => {
        setProduct({ ...product, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:4000/api/products/add', product);
            toast.success('Product added successfully!'); // Show success toast
            setProduct({
                name: '',
                price: '',
                quantity: '',
                brand: '',
                supplier: '',
                oldStock: '',
                category: ''
            });
        } catch (error) {
            toast.error('Failed to add product!'); // Show error toast
        }
    };

    return (
        <div className="add-product-container">
            <h2>Add Product</h2>
            <form onSubmit={handleSubmit} className="add-product-form">
                <input type="text" name="name" value={product.name} onChange={handleChange} placeholder="Product Name" required />
                <input type="number" name="price" value={product.price} onChange={handleChange} placeholder="Price" required />
                <input type="number" name="quantity" value={product.quantity} onChange={handleChange} placeholder="Quantity" required />
                <input type="text" name="brand" value={product.brand} onChange={handleChange} placeholder="Brand" required />
                <input type="text" name="supplier" value={product.supplier} onChange={handleChange} placeholder="Supplier" required />
                <input type="number" name="oldStock" value={product.oldStock} onChange={handleChange} placeholder="Old Stock" required />
                <input type="text" name="category" value={product.category} onChange={handleChange} placeholder="Category" required />
                <button type="submit">Save</button>
            </form>
            <ToastContainer /> {/* Add ToastContainer to your component */}
        </div>
    );
};

export default AddProduct;
