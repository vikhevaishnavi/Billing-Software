import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css'; // Create a CSS file for styling

const Navbar = () => {
    return (
        <nav className="navbar">
            <ul>
                <li><Link to="/">Dashboard</Link></li>
                <li><Link to="/customers">Customers</Link></li>
                <li><Link to="/products">Products</Link></li>
                <li><Link to="/billing">Billing</Link></li>
            </ul>
        </nav>
    );
};

export default Navbar;
