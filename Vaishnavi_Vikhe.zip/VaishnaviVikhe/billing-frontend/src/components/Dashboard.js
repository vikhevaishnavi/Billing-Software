import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Pie, Bar } from 'react-chartjs-2';
import axios from 'axios';
import {
    Chart as ChartJS,
    ArcElement,
    Tooltip,
    Legend,
    BarElement,
    CategoryScale,
    LinearScale,
} from 'chart.js';

// Register necessary components
ChartJS.register(ArcElement, Tooltip, Legend, BarElement, CategoryScale, LinearScale);

const Dashboard = ({ totalSales, additionalData = [] }) => {
    const [totalRevenue, setTotalRevenue] = useState(0);

    useEffect(() => {
        const fetchRevenue = async () => {
            try {
                const response = await axios.get('http://localhost:4000/api/revenue');
                setTotalRevenue(response.data.totalRevenue);
            } catch (error) {
                console.error("Error fetching revenue data:", error);
            }
        };

        fetchRevenue();
    }, []);

    // Prepare data for the pie chart
    const pieData = {
        labels: ['Total Sales', 'Total Revenue'],
        datasets: [
            {
                data: [totalRevenue, totalRevenue],
                backgroundColor: ['#FF6384', '#36A2EB'],
                hoverBackgroundColor: ['#FF6384', '#36A2EB'],
            },
        ],
    };

    // Prepare data for the bar chart
    const barData = {
        labels: ['Total Sales', 'Total Revenue'],
        datasets: [
            {
                label: 'Amount',
                data: [totalRevenue, totalRevenue],
                backgroundColor: ['#FF6384', '#36A2EB'],
            },
        ],
    };

    // Chart options
    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Sales vs Revenue',
            },
        },
    };

    return (
        <div style={{ padding: '20px', textAlign: 'center' }}>
            <h2>Dashboard</h2>
            <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '20px' }}>
                {/* Pie Chart */}
                <div style={{ width: '40%', height: '300px' }}>
                    <h3>Sales vs Revenue (Pie Chart)</h3>
                    <Pie data={pieData} options={options} style={{ height: '100%', width: '100%' }} />
                    <p style={{ fontSize: '18px', fontWeight: 'bold' }}>
                        Total Sales: ${totalRevenue} | Total Revenue: ${totalRevenue}
                    </p>
                </div>

                {/* Bar Chart */}
                <div style={{ width: '40%', height: '300px' }}>
                    <h3>Sales and Revenue (Bar Chart)</h3>
                    <Bar data={barData} options={{
                        responsive: true,
                        plugins: {
                            legend: {
                                display: true,
                            },
                            title: {
                                display: true,
                                text: 'Sales and Revenue',
                            },
                        },
                    }} style={{ height: '100%', width: '100%' }} />
                    <p style={{ fontSize: '18px', fontWeight: 'bold' }}>
                        Total Sales: ${totalRevenue} | Total Revenue: ${totalRevenue}
                    </p>
                </div>
            </div>
        </div>
    );
};

// PropTypes for validation
Dashboard.propTypes = {
    totalSales: PropTypes.number.isRequired,
    additionalData: PropTypes.arrayOf(
        PropTypes.shape({
            label: PropTypes.string.isRequired,
            value: PropTypes.number.isRequired,
        })
    ),
};

export default Dashboard;
