import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import AddCustomer from './components/CustomerManagement/AddCustomer';
import ViewCustomers from './components/CustomerManagement/ViewCustomers';
import AddProduct from './components/ProductManagement/AddProduct';
import ViewProducts from './components/ProductManagement/ViewProducts';
import AddBilling from './components/BillingManagement/AddBilling';
import ViewBilling from './components/BillingManagement/ViewBilling';
import Profile from './components/Profile'; // Import the Profile component

const App = () => {
    const [totalSales, setTotalSales] = useState(0);
    const [totalRevenue, setTotalRevenue] = useState(0);

    return (
        <Router>
            <Header />
            <Navbar />
            <Routes>
                <Route path="/" element={<Dashboard totalSales={totalSales} totalRevenue={totalRevenue} />} />
                <Route path="/customers" element={
                    <>
                        <h2>Customer Management</h2>
                        <AddCustomer />
                        <ViewCustomers />
                    </>
                } />
                <Route path="/products" element={
                    <>
                        <h2>Product Management</h2>
                        <AddProduct />
                        <ViewProducts />
                    </>
                } />
                <Route path="/billing" element={
                    <>
                        <h2>Billing Management</h2>
                        <AddBilling />
                        <ViewBilling />
                    </>
                } />
                <Route path="/profile" element={<Profile />} /> {/* Add Profile route */}
            </Routes>
        </Router>
    );
};

export default App;
